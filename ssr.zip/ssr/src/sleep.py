import time
import subprocess

def countdown(seconds):
    for i in range(seconds, 0, -1):
        print(i)
        time.sleep(1)

def sleep_computer():
    print("Countdown to sleep:")
    countdown(3)
    print("Sleeping...")
    subprocess.call(["shutdown", "/h", "/f"])  # Hibernate and force close applications

if __name__ == "__main__":
    sleep_computer()
