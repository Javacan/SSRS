import tkinter as tk
import time
import os

def shutdown():
    os.system("shutdown /s /t 1")  # Shutdown the PC after 1 second

def update_color():
    global countdown
    if countdown == 3:
        label.config(fg='green')
    elif countdown == 2:
        label.config(fg='yellow')
    elif countdown == 1:
        label.config(fg='red')
    countdown -= 1
    if countdown >= 0:
        label.config(text=str(countdown))
        label.after(1000, update_color)
    else:
        shutdown()

countdown = 3

root = tk.Tk()
root.title("PC Shutdown Countdown")

label = tk.Label(root, text=str(countdown), font=('Helvetica', 48))
label.pack()

update_color()

root.mainloop()

#by charan101_ YT - @J4cn Discord - j4cn#0
