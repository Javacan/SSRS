import tkinter as tk
import time
import os

def restart_pc():
    os.system("shutdown /r /t 1")  # Restart the PC after 1 second

def update_color():
    global countdown
    if countdown == 3:
        label.config(fg='green')
    elif countdown == 2:
        label.config(fg='yellow')
    elif countdown == 1:
        label.config(fg='red')
    countdown -= 1
    if countdown >= 0:
        label.config(text=str(countdown))
        label.after(1000, update_color)
    else:
        restart_pc()

countdown = 3

root = tk.Tk()
root.title("PC Restart Countdown")

label = tk.Label(root, text=str(countdown), font=('Helvetica', 48))
label.pack()

update_color()

root.mainloop()

#by charan101_ YT - @J4cn Discord - j4cn#0